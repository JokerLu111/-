import pygame
import random
import numpy as np
import scipy.ndimage
import time
import threading
import math

# 初始化
pygame.init()
info = pygame.display.Info()
width, height = info.current_w, info.current_h
screen = pygame.display.set_mode((width, height))
clock = pygame.time.Clock()

# 载入杯子图片
images = [
    pygame.image.load("assets/red.png"),
    pygame.image.load("assets/blue.png"),
    pygame.image.load("assets/yellow.png"),
    pygame.image.load("assets/green.png"),
    pygame.image.load("assets/pink.png"),
    pygame.image.load("assets/qing.png"),
    pygame.image.load("assets/orange.png"),
    pygame.image.load("assets/郑丽华.png"),
    pygame.image.load("assets/navy.png"),
    pygame.image.load("assets/shit.png"),
]
cup_width, cup_height = width//3, height//12
images = [pygame.transform.rotate(pygame.transform.scale(assets, (cup_height, cup_width)), -90) for assets in images]

set_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load("assets/set.png"), (width/11, height//24)), -90)
back_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load("assets/back.png"), (width/11, height//24)), -90)

# 颜色定义，后续可能会更新，主要用于再更换背景颜色时字体颜色变化
colors = {
    'black': (0, 0, 0),
    'white': (255, 255, 255)
}

def create_buttons(power): # 字如其名，看不懂的是九漏鱼
    while True:
        numbers = list(range(power)) # 创建一个顺序表
        random.shuffle(numbers) # 打乱顺序
        count = sum(1 for i, number in enumerate(numbers) if number == i) # 对比索引与所对值是否相等，归位量则加一
        if count <= 2: # 检查初始化归位量是否小于定值
            break # 若是小于则打破循环不用再打乱了
    distance = height//6 if power == 5 else (height//8 if power == 7 else height//11)
    front = height//12 if power == 5 else (height//18.5 if power == 7 else height//48)
    return [{'rect': pygame.Rect(width/3.2, front + i * distance, cup_width, cup_height), 'image': images[i], 'number': numbers[i], 'clicks': 0} for i in range(power)] # 列表中的字典推导式，每瓶子的矩形位置图片和序列
 # 将上述函数返回值赋值给此变量
first_selection = None # 初始化首次选中为空

def count_positions(buttons):
    return sum(1 for i, button in enumerate(buttons) if button['number'] == i) # 对比索引与序号，程序有两处需要使用，封装为函数方便

'''这个就不多解读了，CSDN一大堆，随便复制个高斯模糊'''
def apply_gaussian_blur(surface, radius):
    array = pygame.surfarray.array3d(surface)
    gauss_array = scipy.ndimage.gaussian_filter(array, sigma=(radius, radius, 0))
    gauss_surface = pygame.surfarray.make_surface(gauss_array)
    return gauss_surface

# 此函数是替换背景的圆形按钮显示
def draw_circle_buttons(screen):
    radius = int(height/50) # 半径，不认识的九漏鱼
    for i, color in enumerate(back_colors): # 遍历背景选择颜色列表和索引
        pygame.draw.circle(screen, color, (int(width/1.087), int(height/1.263) - i * int(height/16)), radius) # 依次递减画颜色按钮
        pygame.draw.circle(screen, (51, 57, 69), (int(width/1.087), int(height/1.263) - i * int(height/16)), radius, int(height/480)) # 那个小黑圆框框

def handle_events(power):
    global first_selection, gaosi, show_circles, selected_color, buttons, start_time, best_time, game_started, best_time_seconds
    for event in pygame.event.get(): # 获取事件
        if event.type == pygame.QUIT: # 退出事件
            pygame.quit() # 关闭游戏
            exit() # 感觉手机上真没用，就电脑窗口需要关闭
        elif event.type == pygame.MOUSEBUTTONDOWN: # 鼠标事件
            pos = pygame.mouse.get_pos() # 点击位置
            if gaosi and next_button.collidepoint(pos):
                gaosi = False
                buttons = create_buttons(power)
                 # 归位
                first_selection = None
                start_time = None # 重置计时
                game_started = False
            elif set_rect.collidepoint(pos):
                show_circles = not show_circles
            elif show_circles:
                for i, rect in enumerate(color_rects):
                    if rect.collidepoint(pos):
                        selected_color = back_colors[i]
                        show_circles = False
                        break
            elif back_rect.collidepoint(pos):
                return True
            else:
                for button in buttons:
                    if button['rect'].collidepoint(pos):
                         # 增加点击次数
                        if first_selection is None:
                            first_selection = button
                            if not game_started:
                                start_time = time.time() # 记录游戏开始时间
                                game_started = True
                        else:
                            
                            button['clicks'] += 1
                            second_selection = button
                            first_selection['image'], second_selection['image'] = second_selection['image'], first_selection['image'] # 替换图片
                            first_selection['number'], second_selection['number'] = second_selection['number'], first_selection['number']
                            first_selection = None
                            if count_positions(buttons) == power:
                                elapsed_time = time.time() - start_time
                                formatted_time = time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
                                if best_time == "00:00:00" or elapsed_time < best_time_seconds:
                                    best_time = formatted_time
                                    best_time_seconds = elapsed_time
    return False # 这句似乎永远不会发生，PEP8教我这么写的

def render(power = 5):
    screen.fill(selected_color) # 初始背景颜色
    golab_color = colors['black'] if selected_color != colors['black'] else colors['white'] # 三元表达式哈哈，字体颜色
    selected_rect_color = (255, 192, 203) if selected_color == (40, 92, 196) else golab_color
    
    for button in buttons:
        screen.blit(button['image'], button['rect']) # 渲染杯子图片
    
    if first_selection is not None:
        pygame.draw.rect(screen, selected_rect_color, first_selection['rect'], power) # 绘制选中框
    count = count_positions(buttons) # 哈哈，此时需要调用这个函数了

    if count == power: # 全部归位
        render_button(golab_color, power) # 原神启不动，呸，

    render_gui(golab_color)
    pygame.display.flip()

def render_button(golab_color, power): # 高斯模糊效果和渲染下一轮按钮的函数
    global gaosi_surface, gaosi, next_button
    if not gaosi:
        gaosi_surface = apply_gaussian_blur(screen, power)
        gaosi = True
    screen.blit(gaosi_surface, (0, 0))
    next_button = pygame.Rect(width//2.3, height//2.89, width//7.66, height//4.8)
    pygame.draw.rect(screen, golab_color, next_button)
    font = pygame.font.Font('ye.ttf', int(height//48))
    text = pygame.transform.rotate(font.render("下一轮", True, selected_color), -90)
    text_rect = text.get_rect(center=next_button.center)
    screen.blit(text, text_rect)

def render_gui(golab_color):  # 渲染归位量的函数
    font_guiwei = pygame.font.Font('ye.ttf', int(height // 30))
    text = pygame.transform.rotate(font_guiwei.render(f"归位量: {count_positions(buttons)}", True, golab_color), -90)
    screen.blit(text, (int(width / 1.15), int(height / 48)))
    screen.blit(set_image, set_rect.topleft)
    screen.blit(back_image, back_rect.topleft)

    if show_circles:
        draw_circle_buttons(screen)

    pygame.draw.rect(screen, (0, 0, 0), (int(width / 57.5), int(height / 1.41), int(width / 4.79), int(height / 4.8)), int(height / 600))  # 黑色边框
    pygame.draw.rect(screen, (255, 255, 255), (int(width / 47.916), int(height / 1.408), int(width / 4.957), int(height / 4.878)))  # 白色背景
    now_time = pygame.font.Font('ye.ttf', int(height // 46))
    fast_time = pygame.font.Font('ye.ttf', int(height // 60))
    if start_time is not None:
        elapsed_time = time.time() - start_time
        current_time = time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    else:
        current_time = "00:00:00"
    time_text = pygame.transform.rotate(now_time.render(f"当前时间: {current_time}", True, colors['black']), -90)
    best_time_text = pygame.transform.rotate(fast_time.render(f"最快时间: {best_time}", True, colors['black']), -90)
    screen.blit(time_text, (int(width / 7.93), int(height / 1.387)))
    screen.blit(best_time_text, (int(width / 16.42), int(height / 1.344)))

    total = 0  # 声明并初始化点击次数
    for i, button in enumerate(buttons):
        total += button['clicks']
    pygame.draw.rect(screen, (0, 0, 0), (int(width / 57.5), int(height / 40), int(width / 4.79), int(height / 4.8)), int(height / 600))  # 黑色边框
    pygame.draw.rect(screen, (255, 255, 255), (int(width / 47.91), int(height / 37.5), int(width / 4.957), int(height / 4.878)))  # 白色背景
    click_count = pygame.font.Font('ye.ttf', int(height // 43.64))
    ccount_text = pygame.transform.rotate(click_count.render(f"点击次数: {total}", True, colors['black']), -90)
    screen.blit(ccount_text, (int(width / 10), int(height / 14.12)))  
    
next_button = None # 初始化“下一局”按钮为空
gaosi = False # 初始化高斯模糊为假
show_circles = False # 初始化仨点按钮后展开选择背景颜色的五个按钮为假（不会表述）
selected_color = colors['white'] # 初始化选中框颜色为白
music_play = False #音乐开关
playing = False #音乐是否播放中，与暂停二判
music_paused = False #是否暂停
rotation_angle = 0 #旋转角
continue_rotation = False #是否旋转
start_time = None #记录开始时间
best_time = "00:00:00"#默认最快，都没袁宾谦快
best_time_seconds = float('inf')
game_started = False #原神 启动！

set_rect = pygame.Rect(int(width//1.15), int(height//1.2), int(width//11.5), int(height//24)) # 仨点矩形位置
back_rect = pygame.Rect(int(width//1.15), int(height//1.13), int(width//11.5), int(height//24)) # 返回矩形位置
back_colors = [(255, 255, 255), (0, 0, 0), (255, 192, 203), (75, 0, 130), (40, 92, 196)] # 背景选择颜色
color_rects = [pygame.Rect(950, 1900 - i * 150 - 50, 98, 98) for i in range(5)] # 五个背景颜色按钮的矩形位置
# 单选框数据
checkboxes = [
    {"x": int(width//2.68), "y": int(height//6.3157), "checked": True,'number': 5},
    {"x": int(width//2.68), "y": int(height//4.8), "checked": False,'number': 7},
    {"x": int(width//2.68), "y": int(height//3.87), "checked": False,'number': 10}
]

def draw_checkbox(checkbox):
    pygame.draw.circle(screen, colors['black'], (checkbox["x"], checkbox["y"]), height/120, 2)
    if checkbox["checked"]:
        pygame.draw.circle(screen, (0, 0, 255), (checkbox["x"], checkbox["y"]), height/240)

def handle_click(mouse_x, mouse_y):
    for checkbox in checkboxes:
        distance = math.sqrt((mouse_x - checkbox["x"]) ** 2 + (mouse_y - checkbox["y"]) ** 2)
        if distance <= 20: 
            if not checkbox["checked"]:
                for cb in checkboxes:
                    cb["checked"] = False
                checkbox["checked"] = True
            break 
# 旋转动画线程函数，
def zhuan():
    global rotation_angle, continue_rotation
    continue_rotation = True
    while continue_rotation:
        rotation_angle = (rotation_angle + 1) % 360
        time.sleep(0.02)

# 启动旋转动画的线程
def start_zhuan_thread():
    if not continue_rotation:
        thread = threading.Thread(target=zhuan)
        thread.start()
running = True
button_font = pygame.font.Font('ye.ttf', int(height//24))
button_text = pygame.transform.rotate(button_font.render("开始", True, (0, 0, 0)), -90)
button_rect = button_text.get_rect(center=(width//1.9, height/4.8))
jieshao_font = pygame.font.Font('ye.ttf',int(height//48))
jieshao_textone = pygame.transform.rotate(jieshao_font.render('开发：王  林  鹤', True,(255, 192, 203)), -90)
jieshao_texttwo = pygame.transform.rotate(jieshao_font.render('策划：轩辕落雪', True,(255, 192, 203)), -90)
title_image = pygame.transform.scale(pygame.image.load("assets/title.png"), size=(height/10, height/3))
zhuan_image = pygame.transform.scale(pygame.image.load('assets/zhuan.png'), size=(height/16,height/16))
age_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load('assets/18.png'), size=(height/20,height/13)),-90)
zhuan_rect = zhuan_image.get_rect(topleft=(height/2.66,height/120))
pygame.mixer.init()
pygame.mixer.music.load('assets/jap.mp3')
bei_text = pygame.transform.rotate(jieshao_font.render("难度", True, (255, 165, 0)), -90)
bei_text_five = pygame.transform.rotate(jieshao_font.render("5", True, (0, 0, 0)), -90)
bei_text_seven = pygame.transform.rotate(jieshao_font.render("7", True, (0, 0, 0)), -90)
bei_text_ten = pygame.transform.rotate(jieshao_font.render("10", True, (0, 0, 0)), -90)
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = event.pos
            handle_click(mouse_x, mouse_y)
            pos = pygame.mouse.get_pos()
            power = 5
            for checkbox in checkboxes:
            	if checkbox["checked"]:
            		power =checkbox['number']
            		break
            buttons = create_buttons(power)
            if button_rect.collidepoint(pos):
                while True:
                    if handle_events(power):
                        break
                    render(power)
            elif zhuan_rect.collidepoint(pos):
                if music_play:
                    pygame.mixer.music.pause()
                    music_paused = True
                else:
                    pygame.mixer.music.unpause()
                    music_paused = False
                music_play = not music_play
                if not music_play:
                    start_zhuan_thread()
        if not music_play and not playing:
            pygame.mixer.music.play(-1)
            playing = True
            start_zhuan_thread()
        elif music_play:
            pygame.mixer.music.pause()
            music_paused = True
            continue_rotation = False
        elif music_paused:
            pygame.mixer.music.unpause()
            music_paused = False
  
    screen.fill(colors['white'])
    # 绘制单选框
    for checkbox in checkboxes:
        draw_checkbox(checkbox)
    screen.blit(button_text, button_rect)
    screen.blit(title_image, (width/2.091, height/2.18))
    screen.blit(age_image,(width/1.23, height/1.132))
    screen.blit(jieshao_textone, (width/3.83, height/1.8))
    screen.blit(jieshao_texttwo, (width/4.6, height/1.8))# 使用旋转角度渲染图片，只在主线程中操作pygame的图形界面
    screen.blit(bei_text, (width/3.11, height/12))
    screen.blit(bei_text_five, (width/3.48, height/6.575))
    screen.blit(bei_text_seven, (width/3.5, height/4.948))
    screen.blit(bei_text_ten, (width/3.48, height/4))
    rotated_image = pygame.transform.rotate(zhuan_image, rotation_angle)
    rotated_rect = rotated_image.get_rect(center=zhuan_rect.center)
    screen.blit(rotated_image, rotated_rect)

    pygame.display.flip()
    clock.tick(60)
pygame.quit()